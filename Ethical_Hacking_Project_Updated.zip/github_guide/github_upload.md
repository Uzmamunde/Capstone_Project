# GitHub Upload Guide

1. **Initialize Git Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial commit - Ethical Hacking Project"
   ```

2. **Push to GitHub**
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
