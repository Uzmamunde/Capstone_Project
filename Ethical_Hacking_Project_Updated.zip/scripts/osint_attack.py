# OSINT Attack (Björn's Favorite Pet)

import requests

url = "https://www.google.com/search?q=Björn+favorite+pet+site:owasp.org"

print("[+] Search this manually for OSINT info:", url)
